import de.fabmax.kool.KoolApplication
import de.fabmax.kool.addScene
import de.fabmax.kool.pipeline.ClearColorLoad
import de.fabmax.kool.modules.ui2.*
import de.fabmax.kool.util.Color

data class DoorModel(
    val input: String = "",
    val isOpen: Boolean = false,
    val attemptsLeft: Int = 3,
    val message: String = "Введите код"
)

sealed interface DoorEvent {
    data class DigitClicked(val digit: Int) : DoorEvent
    data object EnterClicked : DoorEvent
    data object ClearClicked : DoorEvent
}

val secretCode = "427"

class Store {

    val state = mutableStateOf(DoorModel())

    fun eventbox (event: DoorEvent){
        when(event) {
            is DoorEvent.DigitClicked -> digit(event.digit)
            DoorEvent.EnterClicked -> enter()
            DoorEvent.ClearClicked -> clear()
        }
    }

    fun digit(digit: Int){
        val door = state.value
        if (door.input.length < 3 ){
            state.set(door.copy(input = door.input + digit.toString()))
        } else{
            state.set(door.copy(message = "Поле ввода уже полное"))
        }
    }

    fun enter(){
        val door = state.value
        if (door.input.length == 3 && door.input == secretCode){
            state.set(door.copy( isOpen = true))
        } else{
            state.set(door.copy(message = "Ты просчитался везде"))
            state.set(door.copy(attemptsLeft = door.attemptsLeft - 1))
        }
    }

    fun clear(){
        val door = state.value
        state.set(door.copy(input = ""))
    }
}

fun main() = KoolApplication {
    val store = Store()
    addScene {
        setupUiScene(ClearColorLoad)
        addPanelSurface {
            modifier
                .size(300.dp, 300.dp)
                .align(AlignmentX.Center, AlignmentY.Center)
                .padding(16.dp) // внутренний отступ внутри панели
                .background(RoundRectBackground(Color(0.1f, 0.2f, 0.5f), 14.dp))
            val door = store.state.use()

            Column {
                Text("Ввод: ${door.input}") {}
                Text("Открыта или нет: ${door.isOpen}") {}
                Text("Попыток осталось: ${door.attemptsLeft}") {}
                Text("Сообщение: ${door.message}") {}

                Row {
                    Button("1") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(1))
                            }
                    }

                    Button("2") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(2))
                            }
                    }
                    Button("3") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(3))
                            }
                    }
                }
                Row {
                    Button("4") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(4))
                            }
                    }

                    Button("5") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(5))
                            }
                    }
                    Button("6") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(6))
                            }
                    }
                }
                Row {
                    Button("7") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(7))
                            }
                    }

                    Button("8") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(8))
                            }
                    }
                    Button("9") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.DigitClicked(9))
                            }
                    }
                    Button("Clear") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.ClearClicked)
                            }
                    }
                    Button("Enter") {
                        modifier
                            .margin(end = 5.dp)
                            .margin(start = 5.dp)
                            .margin(top = 5.dp)
                            .margin(bottom = 5.dp)
                            .onClick {
                                store.eventbox(DoorEvent.EnterClicked)

                            }
                    }
                }
            }
        }
    }
}