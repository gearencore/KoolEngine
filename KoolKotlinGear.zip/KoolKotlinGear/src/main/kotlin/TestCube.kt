// ----------------------------
// ИМПОРТЫ (подключаем нужные классы/функции из Kool)
// ----------------------------

import de.fabmax.kool.KoolApplication           // KoolApplication - запускает Kool-приложение (окно + цикл рендера)
import de.fabmax.kool.addScene                  // addScene - функция "добавь сцену" в приложение (у тебя она просила отдельный импорт)

import de.fabmax.kool.math.Vec3f                // Vec3f - 3D-вектор (x, y, z), как координаты / направление
import de.fabmax.kool.math.deg                  // deg - превращает число в "градусы" (угол)
import de.fabmax.kool.scene.*                   // scene.* - Scene, defaultOrbitCamera, addColorMesh, lighting и т.д.

import de.fabmax.kool.modules.ksl.KslPbrShader  // KslPbrShader - готовый PBR-шейдер (материал)
import de.fabmax.kool.util.Color                // Color - цвет (RGBA)
import de.fabmax.kool.util.Time                 // Time.deltaT - сколько секунд прошло между кадрами

import de.fabmax.kool.pipeline.ClearColorLoad   // ClearColorLoad - режим: "не очищай экран, оставь то что уже нарисовано"

import de.fabmax.kool.modules.ui2.*             // UI2: addPanelSurface, Column, Row, Button, Text, dp, remember, mutableStateOf
import de.fabmax.kool.modules.ui2.UiModifier.*  // UiModifier.* - чтобы работали .padding(), .align(), .background(), .size() и т.д.

// ----------------------------
// 1) GameState = "данные игрока" (то, что меняется во время игры)
// ----------------------------
class GameState {
    // mutableStateOf(...) - создаёт "состояние", за которым UI умеет следить
    // когда значение меняется -> UI автоматически перерисуется

    val playerId = mutableStateOf("player")
    // val - ссылка неизменяемая (мы не можем сделать playerId = что-то другое)
    // НО значение внутри state мы менять можем

    val hp = mutableStateOf(100)
    val gold = mutableStateOf(0)

    val poisonTicksLeft = mutableStateOf(0)
    // "тики" = условные шаги времени (как в Minecraft)
    // здесь 1 тик = 1 секунда (для простоты)
}

// ----------------------------
// 2) Точка входа: main()
// ----------------------------
fun main() = KoolApplication {
    // KoolApplication { ... } - запускаем движок и выполняем код внутри блока

    val game = GameState()
    // val game = ... - создаём объект состояния игры (один на всё приложение)

    // ------------------------------------------------------------
    // 3) СЦЕНА 1: WORLD (3D мир)
    // ------------------------------------------------------------
    addScene {
        // this внутри блока = Scene (сцена)

        defaultOrbitCamera()
        // defaultOrbitCamera() - готовая камера "крути вокруг центра мышкой"

        // 3D-куб
        addColorMesh {
            generate {
                cube {
                    colored()
                    // colored() - добавляет цвет на вершины куба (чтобы он был разноцветный)
                }
            }

            shader = KslPbrShader {
                // shader = ... - назначаем материал
                color { vertexColor() }
                // vertexColor() - берём цвет из вершин (из colored())
                metallic(0f)
                roughness(0.25f)
            }

            onUpdate {
                // onUpdate { ... } - вызывается каждый кадр
                // Time.deltaT - секунды между кадрами (важно для одинаковой скорости при разном FPS)

                transform.rotate(45f.deg * Time.deltaT, Vec3f.X_AXIS)
                // rotate(угол, ось)
                // 45f.deg - 45 градусов в секунду
                // * Time.deltaT - "сколько прошло секунд"
                // Vec3f.X_AXIS - ось X
            }
        }

        // Свет (иначе PBR будет тёмным)
        lighting.singleDirectionalLight {
            setup(Vec3f(-1f, -1f, -1f))
            setColor(Color.WHITE, 5f)
        }
    }
}