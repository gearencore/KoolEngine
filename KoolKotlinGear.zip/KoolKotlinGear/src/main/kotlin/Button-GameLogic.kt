import de.fabmax.kool.KoolApplication           // KoolApplication - запускает Kool-приложение (окно + цикл рендера)
import de.fabmax.kool.addScene                  // addScene - функция "добавь сцену" в приложение (у тебя она просила отдельный импорт)

import de.fabmax.kool.math.Vec3f                // Vec3f - 3D-вектор (x, y, z), как координаты / направление
import de.fabmax.kool.math.deg                  // deg - превращает число в "градусы" (угол)
import de.fabmax.kool.scene.*                   // scene.* - Scene, defaultOrbitCamera, addColorMesh, lighting и т.д.

import de.fabmax.kool.modules.ksl.KslPbrShader  // KslPbrShader - готовый PBR-шейдер (материал)
import de.fabmax.kool.util.Color                // Color - цвет (RGBA)
import de.fabmax.kool.util.Time                 // Time.deltaT - сколько секунд прошло между кадрами

import de.fabmax.kool.pipeline.ClearColorLoad   // ClearColorLoad - режим: "не очищай экран, оставь то что уже нарисовано"

import de.fabmax.kool.modules.ui2.*             // UI2: addPanelSurface, Column, Row, Button, Text, dp, remember, mutableStateOf
import de.fabmax.kool.modules.ui2.UiModifier.*
import de.fabmax.kool.modules.ui2.mutableStateOf
import de.fabmax.kool.util.MdColor
import de.fabmax.kool.pipeline.ClearColor


data class HeroModel(
    val hp: Int = 10,
    val maxHp: Int = 10,
    val gold: Int = 5,
    val potions: Int = 0,
    val message: String = "Герой зашёл в таверну"
)

sealed interface TavernEvent {
    data object TakeDamageClicked : TavernEvent
    data object RestClicked : TavernEvent
    data object BuyPotionClicked : TavernEvent
    data object UsePotionClicked : TavernEvent
}
data class Item(
    val id: Int,
    val price: Int,
)
val healpoition = Item(
    1,
    3
)

class GameStore {

    val state = mutableStateOf(HeroModel())

    fun dispatch(event: TavernEvent) {
        when (event) {
            TavernEvent.TakeDamageClicked -> takeDamage()
            TavernEvent.RestClicked -> rest()
            TavernEvent.BuyPotionClicked -> buyPotion()
            TavernEvent.UsePotionClicked -> usePotion()
        }
    }

    fun takeDamage() {
        val hero = state.value // достаём текущего героя из state. Это "актуальная карточка" героя на данный момент
        if (hero.hp <= 0) { // проверяем: если здоровье уже 0 или меньше, урон больше не наносим
            state.set( // set кладёт новую версию героя обратно в state
                hero.copy( // copy создаёт копию hero, но меняет только указанные поля
                    message = "Ты уже помер"
                )
            )
            return // останавливаем функцию, чтобы код ниже не выполнился
        }
        state.set(
            hero.copy(
                hp = (hero.hp - 1).coerceAtLeast(0), // уменьшаем hp на 1, но coerceAtLeast(0) не даёт уйти ниже нуля
                message = "Ты получил 1 урона"
            )
        )
    }

    fun rest() {
        val hero = state.value // берём текущего героя
        state.set(
            hero.copy(
                hp = hero.maxHp,
                message = "Ты отдохнул и восстановил здоровье"
            )
        )
    }

    fun buyPotion() {
        val hero = state.value
        if (hero.gold < 3) {
            state.set(
                hero.copy(
                    message = "Недостаточно золота для покупки зелья"
                )
            )
            return
        }
        state.set(
            hero.copy(
                gold = hero.gold - 3,
                potions = hero.potions + 1,
                message = "Ты купил зелье"
            )
        )
    }

    fun usePotion() {
        val hero = state.value
        if (hero.potions <= 0) {
            state.set(
                hero.copy(
                    message = "У тебя нет зелий"
                )
            )
            return
        }
        if (hero.hp >= hero.maxHp) {
            state.set(
                hero.copy(
                    message = "Здоровье уже полное"
                )
            )
            return
        }
        state.set(
            hero.copy(
                hp = (hero.hp + 3).coerceAtMost(hero.maxHp),
                potions = hero.potions - 1,
                message = "Ты выпил зелье"
            )
        )
    }
}

fun main() = KoolApplication {
    val gameStore = GameStore() // создаём хранилище игры один раз. В нём state героя
    addScene {
        setupUiScene(ClearColorLoad)
        addPanelSurface {
            modifier
                .size(650.dp, 410.dp)
                .align(AlignmentX.Start, AlignmentY.Top)
                .padding(16.dp) // внутренний отступ внутри панели
                .background(RoundRectBackground(Color(0.1f, 0.2f, 0.5f, 0.7f), 14.dp))

            val hero = gameStore.state.use() // use() читает state для UI. Когда state изменится, UI обновится

            Column {
                Text("HP: ${hero.hp}/${hero.maxHp}") {}
                Text("Gold: ${hero.gold}") {}
                Text("Potion: ${hero.potions}") {}
                Text("Message: ${hero.message}") {}

                Row {
                    modifier.margin(top = 15.dp)

                    Button("Heal") {
                        modifier
                            .margin(end = 10.dp)
                            .onClick {
                                gameStore.dispatch(TavernEvent.UsePotionClicked)
                            }
                    }

                    Button("Damage") {
                        modifier
                            .margin(end = 10.dp)
                            .onClick {
                                gameStore.dispatch(TavernEvent.TakeDamageClicked)
                            }
                    }

                    Button("Buy") {
                        modifier
                            .margin(end = 10.dp)
                            .onClick {
                                gameStore.dispatch(TavernEvent.BuyPotionClicked)
                            }
                    }

                    Button("Rest") {
                        modifier.onClick {
                            gameStore.dispatch(TavernEvent.RestClicked)
                        }
                    }
                }
            }
        }
    }
}


