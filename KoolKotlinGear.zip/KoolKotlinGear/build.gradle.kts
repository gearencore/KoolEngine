plugins {
    kotlin("jvm") version "2.2.21"  // Если написана другая версия, то вручную пишем эту
}
group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}
dependencies {
    testImplementation(kotlin("test"))
    implementation("de.fabmax.kool:kool-core:0.19.0")
    implementation("de.fabmax.kool:kool-physics:0.19.0")
}

kotlin {
    jvmToolchain(17) // Здесь указывается ваша версия JDK
}